INSERT INTO poiuy_specialities (name)
VALUES
('G�n�raliste'),
('Neurologue'),
('Oncologue'),
('Cardiologue');
