INSERT INTO poiuy_doctors([lastname],[firstname],[mail],[id_poiuy_specialities]) 
VALUES
('Everett','Reed','ut.molestie@vitae.com', 1),
('Woodard','Winter','lectus@malesuada.com',1),
('Mccarthy','Imani','quis.massa@tinciduntvehicularisus.com', 2),
('Morin','Suki','fringilla.Donec@ametanteVivamus.com', 2),
('Duke','Arden','consectetuer.cursus.et@cursuspurus.com', 3),
('Mckee','Pearl','netus.et@facilisis.com', 3),
('Sanford','Idona','sit.amet.luctus@pellentesque.com', 4),
('Kline','Carly','Donec.tempor@nec.com', 4);